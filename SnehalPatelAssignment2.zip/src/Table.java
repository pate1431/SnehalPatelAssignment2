/*
             !!! PROGRAM TO PRINT THE TABLE USING POW FUNCTION OF MATH CLASS !!!
*/
public class Table
{
    public static void main(String ar[])
    {
        int A,b;

        //      Statements below displays Headings of the table
        System.out.print("A\tb\tpow(A,b)");

        //      Statements below displays Line 1 of the table
        A=1;
        b=2;
        System.out.print("\n"+A+"\t"+b+"\t"+(int)Math.pow(A,b));

        //      Statements below displays Line 2 of the table
        A=2;
        b=3;
        System.out.print("\n"+A+"\t"+b+"\t"+(int)Math.pow(A,b));

        //      Statements below displays Line 3 of the table
        A=3;
        b=4;
        System.out.print("\n"+A+"\t"+b+"\t"+(int)Math.pow(A,b));
    }
}
/*
                                    !!! THE END !!!
                                       THANK YOU
 */
